
var Global= require('../../libs/global/global.js');
const baseAuthor={
            actor: '',
            permission: Global.acPermission
        }

module.exports = baseAuthor