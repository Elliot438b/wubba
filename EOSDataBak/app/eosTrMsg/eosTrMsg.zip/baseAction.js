const baseAc={
    account: '',
    name: '',
    authorization: [
       
    ],
   data:'',
}

module.exports = baseAc