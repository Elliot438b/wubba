const baseAc = require('../baseAction.js');
const baseTr = require('../baseTr.js');
const baseAuthor = require('../baseAuthor.js');

const dealerWitdawDS={
    
    tableId:'',  //table主键
    withdraw:''    //提取额
};


// baseAc.name='dealerwitdaw';    //方法名

// baseAc.authorization.push(baseAuthor);
// baseAc.data=dealerWitdawDS;

// baseTr.actions.push(baseAc);

const commDealerWitdaw=new baseTr();

module.exports = {commDealerWitdaw,dealerWitdawDS}